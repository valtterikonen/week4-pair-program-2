const services = [
    {
        id: 1,
        icon: "fas fa-wallet",
        title: "Saving Money",
        text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, officia.",
    },
    {
        id: 2,
        icon: "fas fa-car",
        title: "Car Repair",
        text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, officia.",
    },
    {
        id: 3,
        icon: "fas fa-home",
        title: "Home Cleaning",
        text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, officia.",
    },
    {
        id: 4,
        icon: "fas fa-plug",
        title: "Electrical Services",
        text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, officia.",
    },
    {
        id: 5,
        icon: "fas fa-paint-brush",
        title: "Painting Services",
        text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, officia.",
    },
];

module.exports = services;